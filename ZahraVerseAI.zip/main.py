from modules.quran import ambil_quran
from modules.hadits import cari_hadits
from modules.doa import ambil_doa
from modules.audio import tts_play, format_arabic
from modules.subtitle import buat_subtitle
from karakter import kenali_karakter

import os
os.makedirs("data/naskah", exist_ok=True)

# Ucapan Pembuka
print("بِسْمِ اللَّهِ الرَّحْمَـٰنِ الرَّحِيمِ")
print("Bismillāhir-raḥmānir-raḥīm")
print("Dengan nama Allah Yang Maha Pengasih, Maha Penyayang\n")
print("Dengan hormat, saya ZahraVerseAI siap membantu Anda ✨")

while True:
    u = input("\nKamu: ").strip().lower()

    if u.startswith("quran"):
        parts = u.split()
        if len(parts) == 3:
            s, a = parts[1], parts[2]
            hasil = ambil_quran(s, a)
            if "error" in hasil:
                print("Error:", hasil["error"])
            else:
                print("Arab:", format_arabic(hasil["arab"]))
                print("Latin:", hasil["latin"])
                print("Arti:", hasil["translation"])
                tts_play(format_arabic(hasil["arab"]), lang='ar', filename="quran_arab.mp3")
                tts_play(hasil["translation"], lang='id', filename="quran_id.mp3")
        else:
            print("Format: quran <surah> <ayat>")

    elif u.startswith("hadits"):
        tema = u.replace("hadits", "").strip() or "niat"
        hasil = cari_hadits(tema)
        if not hasil:
            print("Error: Tidak ditemukan")
        else:
            h = hasil[0]
            print("Arab:", format_arabic(h["arab"]))
            print("Latin:", h["latin"])
            print("Arti:", h.get("terjemah") or h.get("arti") or h.get("terjemahan", "Terjemahan tidak ditemukan"))
            print("Sumber:", h.get("sumber", "Tidak diketahui"))
            tts_play(format_arabic(h["arab"]), lang='ar', filename="hadits_ar.mp3")
            tts_play(h.get("terjemah") or h.get("arti") or h.get("terjemahan"), lang='id', filename="hadits_id.mp3")

    elif u == "doa":
        hasil = ambil_doa()
        if "error" in hasil:
            print("Error:", hasil["error"])
        else:
            print("Doa:", hasil['doa'])
            print("Arab:", format_arabic(hasil['arab']))
            print("Arti:", hasil['arti'])
            tts_play(format_arabic(hasil['arab']), lang='ar', filename="doa_arab.mp3")
            tts_play(hasil['arti'], lang='id', filename="doa_id.mp3")

    elif u.startswith("siapa"):
        nama = u.replace("siapa", "").strip()
        karakter = kenali_karakter(nama)
        if karakter:
            print(f"Karakter: {karakter}")
        else:
            print("Karakter tidak ditemukan.")

    elif u.startswith("subtitle "):
        teks = u[len("subtitle "):]
        buat_subtitle(teks, filename="data/naskah/subtitle.srt")
        print("Subtitle dibuat: data/naskah/subtitle.srt")

    elif u in ["exit", "keluar", "selesai"]:
        print("\nوَٱللَّهُ أَعْلَمُ بِٱلصَّوَابِ")
        print("Wallāhu a‘lamu bissawāb")
        print("Dan Allah-lah Yang Maha Mengetahui segala kebenaran")
        print("ZahraVerseAI keluar. Sampai jumpa!")
        break

    else:
        print("Perintah: quran <surah> <ayat>, hadits <tema>, doa, siapa <nama>, atau subtitle <teks>")
