import requests
from urllib.parse import quote

def ambil_quran(surah, ayat):
    try:
        surah_enc = quote(surah)
        url = f"https://api.alquran.cloud/v1/ayah/{surah_enc}:{ayat}/editions/quran-uthmani,transliteration,id.indonesian"
        res = requests.get(url).json()
        if res['status'] != 'OK': raise Exception("Ayat tidak ditemukan")
        data = res['data']
        return {
            "arab": data[0]['text'],
            "latin": data[1]['text'],
            "translation": data[2]['text']
        }
    except Exception as e:
        return {"error": str(e)}

