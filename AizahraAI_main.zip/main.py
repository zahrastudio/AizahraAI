from modules.quran import ambil_quran
from modules.hadits import cari_hadits
from modules.doa import ambil_doa
from modules.audio import tts_play, format_arabic, tts_gtts
from modules.subtitle import buat_subtitle
from karakter import kenali_karakter
from modules.maps import cari_gambar_pixabay, link_google_maps
from modules.translate import translate_teks
from karakter import kenali_karakter
from karakter_ import kenali_karakter_sahabat
import os

# Contoh panggil gTTS untuk baca terjemahan dan Arab
tts_gtts("Dengan nama Allah Yang Maha Pengasih, Maha Penyayang", filename="bismillah_id.mp3")
tts_gtts("بِسْمِ اللَّهِ الرَّحْمَـٰنِ الرَّحِيمِ", lang='ar', filename="bismillah_ar.mp3")

os.makedirs("data/naskah", exist_ok=True)

# Ucapan Pembuka
print("بِسْمِ اللَّهِ الرَّحْمَـٰنِ الرَّحِيمِ")
print("Bismillāhir-raḥmānir-raḥīm")
print("Dengan nama Allah Yang Maha Pengasih, Maha Penyayang")
print("Dengan hormat, saya ZahraVerseAI siap membantu Anda ✨")

while True:
    u = input("\nKamu: ").strip().lower()

    if u.startswith("quran"):
        parts = u.split()
        if len(parts) == 3:
            s, a = parts[1], parts[2]
            hasil = ambil_quran(s, a)
            if "error" in hasil:
                print("Error:", hasil["error"])
            else:
                print("Arab:", format_arabic(hasil["arab"]))
                print("Latin:", hasil["latin"])
                print("Arti:", hasil["translation"])
                tts_play(format_arabic(hasil["arab"]), lang='ar', filename="quran_arab.mp3")
                tts_play(hasil["translation"], lang='id', filename="quran_id.mp3")
        else:
            print("Format: quran <surah> <ayat>")

    elif u.startswith("hadits"):
        tema = u.replace("hadits", "").strip() or "niat"
        hasil = cari_hadits(tema)
        if not hasil:
            print("Error: Tidak ditemukan")
        else:
            h = hasil[0]
            print("Arab:", format_arabic(h["arab"]))
            print("Latin:", h["latin"])
            print("Arti:", h.get("terjemah") or h.get("arti", "Tidak ada arti"))
            print("Sumber:", h.get("sumber", "Tidak diketahui"))
            tts_play(format_arabic(h["arab"]), lang='ar', filename="hadits_ar.mp3")
            tts_play(h.get("terjemah") or h.get("arti", ""), lang='id', filename="hadits_id.mp3")

    elif u == "doa":
        hasil = ambil_doa()
        if "error" in hasil:
            print("Error:", hasil["error"])
        else:
            print("Doa:", hasil['doa'])
            print("Arab:", format_arabic(hasil['arab']))
            print("Arti:", hasil['arti'])
            tts_play(format_arabic(hasil['arab']), lang='ar', filename="doa_arab.mp3")
            tts_play(hasil['arti'], lang='id', filename="doa_id.mp3")

    elif u.startswith("siapa"):
        nama = u.replace("siapa", "").strip()
        ditemukan = kenali_karakter(nama)
        if not ditemukan:
            ditemukan = kenali_karakter_sahabat(nama)
        if not ditemukan:
            print("❌ Karakter tidak ditemukan.")
    elif u.startswith("subtitle "):
        teks = u[len("subtitle "):]
        buat_subtitle(teks, filename="data/naskah/subtitle.srt")
        print("Subtitle dibuat: data/naskah/subtitle.srt")

    elif u.startswith("translate "):
        teks = u.replace("translate", "").strip()
        hasil = translate_teks(teks, target='id')
        print("🈯 Terjemahan:", hasil)

    elif u.startswith("gambar "):
        keyword = u.replace("gambar", "").strip()
        hasil = cari_gambar_pixabay(keyword)
        if hasil:
            print(f"🔍 Gambar '{keyword}':")
            for h in hasil:
                print(h["webformatURL"])
        else:
            print("❌ Gambar tidak ditemukan.")

    elif u.startswith("maps "):
        keyword = u.replace("maps", "").strip()
        link = link_google_maps(keyword)
        print(f"🗺️ Buka di browser: {link}")

    elif u in ["exit", "keluar", "selesai"]:
        print("\nوَٱللَّهُ أَعْلَمُ بِٱلصَّوَابِ")
        print("Wallāhu a‘lamu bissawāb")
        print("Dan Allah-lah Yang Maha Mengetahui segala kebenaran")
        print("ZahraVerseAI keluar. Sampai jumpa!")
        break

    else:
        print("Perintah: quran <surah> <ayat>, hadits <tema>, doa, siapa <nama>, subtitle <teks>, translate <teks>, gambar <kata>, maps <lokasi>")

